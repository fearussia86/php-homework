<p>Наши контакты</p>
<p>тел: 8-800-888-55-55</p>

<?php include_once $data;?>